from flask import Flask
app = Flask(__name__)


app.secret_key = 'lol okay'
DATABASE = 'sasquatch' #update this one to match new schema model !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!+1